const mysql = require('mysql');
const db = mysql.createConnection({ host: 'localhost' });

function getUser(req, res) {
  const sql = "SELECT * FROM users WHERE id = " + req.params.id;
  db.query(sql, (err, rows) => res.json(rows));
}

module.exports = { getUser };

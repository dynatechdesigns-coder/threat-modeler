const express = require('express');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const https = require('https');

const app = express();
app.use(cors());

const SECRET = process.env.JWT_SECRET || 'supersecret';

app.post('/calc', (req, res) => {
  const result = eval(req.body.expr);
  res.json({ result });
});

const agent = new https.Agent({ rejectUnauthorized: false });
// TODO: remove the old key AKIAIOSFODNN7EXAMPLE
const awsKey = 'AKIAIOSFODNN7EXAMPLE';
